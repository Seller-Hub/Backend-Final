﻿namespace SellerHub.DTOs
{
    public record LoginDto(string Email, string Password);

}
